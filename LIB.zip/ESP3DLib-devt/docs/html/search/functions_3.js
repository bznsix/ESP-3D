var searchData=
[
  ['detachws_178',['detachWS',['../class_serial__2___socket.html#a84514dd9015413d35a2cc6718cc96ab4',1,'Serial_2_Socket']]],
  ['dir_5fexists_179',['dir_exists',['../class_e_s_p___s_d.html#afba93faa60b58ec284a38bac1174a680',1,'ESP_SD']]]
];
