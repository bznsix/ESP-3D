var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstwx~",
  1: "esw",
  2: "ensw",
  3: "abcdefghimoprsw~",
  4: "eipsw",
  5: "l",
  6: "l",
  7: "_adefhmnprstx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

