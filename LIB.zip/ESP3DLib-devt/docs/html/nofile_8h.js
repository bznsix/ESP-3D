var nofile_8h =
[
    [ "PAGE_NOFILES_SIZE", "nofile_8h.html#af1ab057626205fe1d5dae5474f4774aa", null ],
    [ "PROGMEM", "nofile_8h.html#a4bb34006af954f26383a423ffe5b887f", null ]
];